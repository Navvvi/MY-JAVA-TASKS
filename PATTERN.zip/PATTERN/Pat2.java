import java.util.Scanner;
public class Pat2 
{
    public static void main(String [] args)
    {
        Scanner scan = new Scanner(System.in);

        System.out.println("GIVE YOUR STRING");

       String str = scan.nextLine();
       char c[]=str.toCharArray();

	for(int i=0;i<c.length;i++)
	{
		//System.out.println(c[i]);
	}
	//System.out.println(str.charAt(5)); 
	
	int m = 4;
	int n = 3;
			
	String s1 = str.substring(0,m);
	String s2 = str.substring(m+1,m+n+1);
	String s3 = str.substring(m+n+1,str.length());	
	//System.out.println(s1+" "+s2+" "+s3);
	
	char[] charArray = s1.toCharArray();

	System.out.println(s1+"\n"+" "+s2+"\n"+s3);
	
	 
    }
}