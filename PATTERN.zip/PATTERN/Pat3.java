import java.io.*;
import java.util.Scanner;
class Func1
{
	public static void main(String a[])
	{
		System.out.println("ENTER THE STRING..");
		Scanner s=new Scanner(System.in);
		String str=s.nextLine();
		char arr[]=str.toCharArray();
		int w=str.length();
		for(int i=0;i<(w/2)+1;i++)
		{
			for(int j=0;j<str.length();j++ )
			{
				if(j==i || j == (w-1-i))
				{
					System.out.print(arr[j]);
				}
				else
				{
					System.out.print(" ");
				}
			}
				System.out.println("");
		}
	}
}
